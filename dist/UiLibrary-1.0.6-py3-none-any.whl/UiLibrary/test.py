from UiLibrary import screen 
from UiLibrary import addButtom
from UiLibrary import addNumBox
from UiLibrary import addlable
from UiLibrary import textboxoutput
from UiLibrary import mainsloop

screen()
addButtom("grhg4f",textboxoutput)
addNumBox()
addlable()
help(addlable)
help(addNumBox)
help(addButtom)
mainsloop()